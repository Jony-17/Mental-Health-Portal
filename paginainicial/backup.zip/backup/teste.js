const dadosIdioma = {
    "pt": {
        "title": "Portal de Saúde Mental",
        "home": {
            "welcome": "Bem-vindo ao Portal de Saúde Mental",
            "intro": "Este portal oferece informações e recursos sobre saúde mental.",
            "buttonintro": "Saiba mais"
        },
        "about": {
            "mission": "Nossa missão é promover a saúde mental e o bem-estar.",
            "team": "Conheça nossa equipe de profissionais qualificados."
        }
    },
    "en": {
        "title": "Mental Health Portal",
        "home": {
            "welcome": "Welcome to the Mental Health Portal",
            "intro": "This portal offers information and resources on mental health.",
            "buttonintro": "Know more"
        },
        "about": {
            "mission": "Our mission is to promote mental health and well-being.",
            "team": "Meet our team of qualified professionals."
        }
    }
};

const langButtonPT = document.getElementById('langButtonPT');
const langButtonEN = document.getElementById('langButtonEN');

// Retrieve stored language preference
const storedLang = localStorage.getItem('language');
let currentLang = storedLang || 'pt'; // Set default language to 'pt' if not stored

// Update page content based on stored language
document.title = dadosIdioma[currentLang].title;
document.getElementById('titulo-boas-vindas').textContent = dadosIdioma[currentLang].home.welcome;
document.getElementById('titulo-texto').textContent = dadosIdioma[currentLang].home.intro;
document.getElementById('button-texto').textContent = dadosIdioma[currentLang].home.buttonintro;

langButtonPT.addEventListener('click', function() {
  // Update language preference
  currentLang = 'pt';
  localStorage.setItem('language', currentLang);

  // Update page content
  document.title = dadosIdioma[currentLang].title;
  document.getElementById('titulo-boas-vindas').textContent = dadosIdioma[currentLang].home.welcome;
  document.getElementById('titulo-texto').textContent = dadosIdioma[currentLang].home.intro;
  document.getElementById('button-texto').textContent = dadosIdioma[currentLang].home.buttonintro;

});

langButtonEN.addEventListener('click', function() {
  // Update language preference
  currentLang = 'en';
  localStorage.setItem('language', currentLang);

  // Update page content
  document.title = dadosIdioma[currentLang].title;
  document.getElementById('titulo-boas-vindas').textContent = dadosIdioma[currentLang].home.welcome;
  document.getElementById('titulo-texto').textContent = dadosIdioma[currentLang].home.intro;
  document.getElementById('button-texto').textContent = dadosIdioma[currentLang].home.buttonintro;

});
